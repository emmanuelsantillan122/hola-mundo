const express = require('express');
const router = express.Router();
const carController = require('../controller/carController');


router.post('/rent', carController.rentCar);

module.exports = router;
