import React from 'react';
import { StyleSheet, Text, View } from 'react-native';

const SettingsScreen = () => {
  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#e7e7e7",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <Text>Settings Screen</Text>
    </View>
  );
};

export default SettingsScreen;